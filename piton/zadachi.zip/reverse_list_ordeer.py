list1 = [10, 20, 30, 40]
list2 = [100, 200, 300, 400]
list2.reverse()
print(list1, '\n', list2)
