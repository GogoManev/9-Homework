aTuple = (10, 20, 30, 40)
a = aTuple[0]
b = aTuple[1]
c = aTuple[2]
d = aTuple[3]
print(a)
print(b)
print(c)
print(d)
