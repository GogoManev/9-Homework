sampleSet = {"Yellow", "Orange", "Black"}
sampleList = ["Blue", "Green", "Red"]


for i in range(len(sampleList)):
    sampleSet.add(sampleList[i])

print(sampleSet)
